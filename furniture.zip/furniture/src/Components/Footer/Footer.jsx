import React, { useState } from "react";
import styles from "./Footer.module.css";
import { MdKeyboardArrowUp } from "react-icons/md";
import { Link } from "react-router-dom";
import {
  FaFacebookF,
  FaTwitter,
  FaLinkedinIn,
  FaYoutube,
  FaDribbble,
} from "react-icons/fa";
import { ImInstagram } from "react-icons/im";
import { IoIosPaperPlane } from "react-icons/io";
import { BsFillCaretDownFill, BsFillCaretUpFill } from "react-icons/bs";
import android from "../../Assets/android.png";
import ios from "../../Assets/ios.png";

const Footer = () => {
  const [click1, setClick1] = useState(false);
  const [click2, setClick2] = useState(false);
  const [click3, setClick3] = useState(false);
  const [click4, setClick4] = useState(false);

  const handleClick1 = () => {
    setClick1(!click1);
  };
  const handleClick2 = () => {
    setClick2(!click2);
  };
  const handleClick3 = () => {
    setClick3(!click3);
  };
  const handleClick4 = () => {
    setClick4(!click4);
  };

  const goToUp = () => {
    window.scrollTo({ top: 0, left: 0, behavior: "smooth" });
  };

  return (
    <div>
      <div className={styles.___main__footer__}>
        <div className={styles.__footer__main__content__}>

        
          <div></div>
          {/* <button className={styles.__read__more__}>
            Read More <MdKeyboardArrowRight />
          </button> */}

          <div className={styles.__site__info__}>
            <div>
              
            <h3 onClick={handleClick1}>
               
                {click1 ? (
                  <span>
                    <BsFillCaretUpFill />
                  </span>
                ) : (
                  <span>
                    <BsFillCaretDownFill />
                  </span>
                )}
              </h3>
              <div
                className={
                  click1
                    ? `${styles.__site_details__} ${styles.active}`
                    : `${styles.__site_details__}`
                }
              >
                <Link to="">
                  <p>About US</p>
                </Link>
                <Link to="">
                  <p>Culture</p>
                </Link>
                <Link to="">
                  <p>Investors</p>
                </Link>
                <Link to="">
                  <p>Careers</p>
                </Link>
                <Link to="">
                  {" "}
                  <p>Contact</p>
                </Link>
                <Link to="">
                  <p>Our Benefits</p>
                </Link>
                <Link to="">
                  <p>Sitemap</p>
                </Link>
              </div>
            </div>

            <div>
              <h3 onClick={handleClick2}>
                INFORMATION
                {click2 ? (
                  <span>
                    <BsFillCaretUpFill />
                  </span>
                ) : (
                  <span>
                    <BsFillCaretDownFill />
                  </span>
                )}
              </h3>
              <div
                className={
                  click2
                    ? `${styles.__site_details__} ${styles.active}`
                    : `${styles.__site_details__}`
                }
              >
                <Link to="">
                  <p>Blog</p>
                </Link>
                <Link to="">
                  <p>FAQs</p>
                </Link>
                <Link to="">
                  <p>Documents Required</p>
                </Link>
              </div>
            </div>

            <div>
              <h3 onClick={handleClick3}>
                POLICIES
                {click3 ? (
                  <span>
                    <BsFillCaretUpFill />
                  </span>
                ) : (
                  <span>
                    <BsFillCaretDownFill />
                  </span>
                )}
              </h3>
              <div
                className={
                  click3
                    ? `${styles.__site_details__} ${styles.active}`
                    : `${styles.__site_details__}`
                }
              >
                <Link to="">
                  <p>Shipping Policy</p>
                </Link>
                <Link to="">
                  <p>Cancellation & Return</p>
                </Link>
                <Link to="">
                  <p>Privacy Policy</p>
                </Link>
                <Link to="">
                  <p>Rental Terms & Conditions</p>
                </Link>
                <Link to="">
                  {" "}
                  <p>Referral Terms & Conditions</p>
                </Link>
              </div>
            </div>

            <div>
              <h3 onClick={handleClick4}>
                NEED HELP ?
                {click4 ? (
                  <span>
                    <BsFillCaretUpFill />
                  </span>
                ) : (
                  <span>
                    <BsFillCaretDownFill />
                  </span>
                )}
              </h3>
              <div
                className={
                  click4
                    ? `${styles.__site_details__} ${styles.active}`
                    : `${styles.__site_details__}`
                }
              >
                <div className={styles.chat__option}>
                  <button>Chat with us (9AM - 6PM)</button>
                </div>
                <div className={styles.__mail_rento__}>
                  <a
                    href="mailto:subah.com"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <IoIosPaperPlane /> shubah2233
                  </a>
                </div>
                <h3>DOWNLOAD APP</h3>
                <div className={styles.__store_anios}>
                  <div>
                    <img src={android} alt="android" />
                  </div>
                  <div>
                    <img src={ios} alt="ios" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <hr />

          <div className={styles.__social__}>
            <div>shubham reehan farha ashirbad</div>
            <div className={styles.__social__icons__}>
            
            </div>
            <div>
              <button onClick={goToUp}>
                Go Up <MdKeyboardArrowUp />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Footer;
