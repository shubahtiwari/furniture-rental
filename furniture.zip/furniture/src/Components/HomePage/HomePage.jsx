import React, { useContext } from "react";
import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import styles from "./HomePage.module.css";
import "./Carousel.css";
import { IoIosArrowDroprightCircle } from "react-icons/io";

import img1 from "../../Assets/carouselImage/bangalore.gif";
import img2 from "../../Assets/carouselImage/fitness.jpg";
import img3 from "../../Assets/carouselImage/ac.jpg";
import img4 from "../../Assets/carouselImage/paytm.jpg";

// icons
import covid_icon from "../../Assets/carouselImage/protection.png";
import { Link } from "react-router-dom";
import ProductCarousel from "./ProductCarousel";

import MoreData from "./MoreRent";
import Subscriber from "./Subscriber";
import { CityContext } from "../../Context/CityContext";

const category_arr = [
  {
    id: 1,
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="64"
        height="64"
        viewBox="0 0 18 18"
        id="new-packages"
        y="806"
      >
        <g fill="none" fillRule="evenodd" stroke="#434A54" strokeWidth=".4">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M4 6.114L8.991 3.5l4.992 2.614v.345L8.99 9.073 4 6.467z"
          />
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M4 6.45l4.991 2.638 4.992-2.639v5.432l-5.007 2.614L4 11.88z"
          />
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M8.991 14.315V9.088L4.031 6.51 4 6.662v5.219z"
          />
          <path
            fill="#4DDFD2"
            d="M5.75 5.22l5.137 2.862 1.02-.54-5.289-2.793z"
          />
          <path
            fill="#4DDFD2"
            d="M10.75 8.153l1.05-.567-.036 1.684-.408-.056-.606.444V8.153z"
          />
        </g>
      </svg>
    ),
    name: "Packages",
  },
  {
    id: 2,
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="64"
        height="64"
        viewBox="0 0 18 18"
        id="new-furniture"
        y="742"
      >
        <g fill="none" fillRule="evenodd">
          <path
            stroke="#434A54"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth=".4"
            d="M12.348 5.191H5.433c-.695 0-1.259.548-1.259 1.225v1.58h9.432v-1.58c0-.677-.563-1.225-1.258-1.225z"
          />
          <path
            fill="#4DDFD2"
            d="M8.984 9.456v-.802c0-.7-.582-1.266-1.3-1.266H5.266c-.718 0-1.3.566-1.3 1.266v.802"
          />
          <path
            stroke="#434A54"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth=".4"
            d="M8.984 9.456v-.802c0-.7-.582-1.266-1.3-1.266H5.266c-.718 0-1.3.566-1.3 1.266v.802"
          />
          <path
            fill="#4DDFD2"
            d="M14.013 9.456v-.802c0-.7-.583-1.266-1.302-1.266h-2.415c-.719 0-1.302.566-1.302 1.266v.802"
          />
          <path
            stroke="#434A54"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth=".4"
            d="M14.013 9.456v-.802c0-.7-.583-1.266-1.302-1.266h-2.415c-.719 0-1.302.566-1.302 1.266v.802m5.008 3.244H3.778a.593.593 0 01-.6-.584v-2.63h11.425v2.63a.592.592 0 01-.6.585z"
          />
        </g>
      </svg>
    ),
    name: "Furniture",
  },
  
];

const HomePage = () => {
  const { city } = useContext(CityContext);
  const slide = [img1, img2, img3, img4];

  return (
    <div>
      <div className={styles.outer_slider}>
        <div className={styles.img_slider}>
          <Carousel autoPlay infiniteLoop>
            {slide.map((item, i) => (
              <img key={i} src={item} alt="img_slide" />
            ))}
          </Carousel>
          <div className={styles.covid_19_saftey}>
            <span>
              <img src={covid_icon} alt="covid" />
            </span>
            <span className={styles.covid_sen}>
              Safety precautions during COVID-19. We’re taking additional steps
              and precautionary measures to protect our community from COVID-19.
            </span>
            <Link>
              <span className={styles.knowmore}>
                Know more <IoIosArrowDroprightCircle />
              </span>
            </Link>
          </div>
        </div>
      </div>

      <div className={styles.allCategoty}>
        {category_arr.map(({ id, icon, name }) => (
          <div
            title={
              name === "Furniture"
                ? "Click to Check the Furniture Product"
                : "No Product, we are scaling our inventory"
            }
          >
            <Link
              to={`/${city}/${name}`}
              key={id}
              className={
                name === "Furniture"
                  ? styles.__furniture__
                  : styles.eachCategory
              }
            >
              <div>{icon}</div>
              <p>{name}</p>
            </Link>
          </div>
        ))}
      </div>

      {/* productCarousel  */}
      <div className={styles.fullProduct_section}>
        <div className={styles.productTitle__des}>
          <p className={styles.title__des}>
            You'll love to <span>take these home</span>
          </p>
          <div></div>
        </div>
        <div className={styles.product_Carousel}>
          <ProductCarousel />
        </div>
      </div>

      {/* there's more thins  */}
      <div className={styles.__moreThingsRent__}>
        <p className={styles.title__des}>
          There's more <span>to renting</span>
        </p>
        <div></div>
        <div className={styles.__more_rent__}>
          {MoreData?.map((item) => (
            <div key={item.id} className={styles.each__more__rent}>
              {item.icons}
              <p>{item.title}</p>
              <p>{item.discription}</p>
            </div>
          ))}
        </div>
      </div>
      <div>
        <Link to="" className={styles.__knowMore__}>
          KNOW MORE
        </Link>
      </div>

      
          <div>
            <Subscriber />
          </div>
        </div>
    
  );
};

export default HomePage;
