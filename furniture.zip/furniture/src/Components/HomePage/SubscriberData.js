const subsData = [
    
]

export default subsData