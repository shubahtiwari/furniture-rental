import React from "react";
import HomePage from "../Components/HomePage/HomePage";
const Home = () => {

  return (
    <div>
      <HomePage />
    </div>
  );
};

export default Home;
